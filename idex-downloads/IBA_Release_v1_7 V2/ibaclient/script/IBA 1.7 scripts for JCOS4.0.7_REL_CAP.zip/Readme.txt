Copy the 2 new files to the directory:

IBA_Release_v1_7\ibaclient\script

Execute the script "jcshell -f onestop-REL.jcsh"
